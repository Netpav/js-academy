# JavaScript Academy

## Env
- node.js (4.x)

## Install

    npm install

## Local dev

    npm run dev

Then navigate to [localhost:8080](http://localhost:8080)
